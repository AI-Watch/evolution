Selected AI Breakthroughs for the AI Watch Timeline (timeline.csv)
Format: CSV (Comma Separated Values)
For each breakthrough we have:
- Year
- Title
- Description
- AI Domain, as described in [1]
- Secondary AI Domain, as described in [1]
- AI Subdomain, as described in [1]
- Indication if it is an EU Activity

[1] Samoili, S., Lopez Cobo, M., Gomez Gutierrez, E., De Prato, G., Martinez-Plumed, F. and Delipetrev, B., AI WATCH. Defining Artificial Intelligence, EUR 30117 EN, Publications Office of the European Union, Luxembourg, 2020, ISBN 978-92-76-17045-7 (online), doi:10.2760/382730 (online), JRC118163.
